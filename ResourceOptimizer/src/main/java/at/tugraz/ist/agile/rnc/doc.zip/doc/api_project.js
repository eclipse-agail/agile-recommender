define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-03-25T18:12:38.750Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
