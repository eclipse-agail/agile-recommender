define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-09-06T10:39:10.561Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
